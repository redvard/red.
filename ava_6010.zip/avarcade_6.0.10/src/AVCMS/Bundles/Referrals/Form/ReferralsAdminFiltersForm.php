<?php

namespace AVCMS\Bundles\Referrals\Form;

use AVCMS\Bundles\Admin\Form\AdminFiltersForm;

class ReferralsAdminFiltersForm extends AdminFiltersForm
{
}