<?php

namespace AVCMS\Bundles\CmsFoundation\Form;

use AV\Form\FormBlueprint;

class ModulePositionAdminForm extends FormBlueprint
{
    public function __construct()
    {
    }
}