<?php

namespace AVCMS\Bundles\Adverts\Form;

use AVCMS\Bundles\Admin\Form\AdminFiltersForm;

class AdvertsAdminFiltersForm extends AdminFiltersForm
{
}