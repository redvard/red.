<?php
/**
 * User: Andy
 * Date: 12/01/15
 * Time: 19:43
 */

namespace AVCMS\Bundles\Users\Model;

class AnonymousUser extends User
{
    
}
