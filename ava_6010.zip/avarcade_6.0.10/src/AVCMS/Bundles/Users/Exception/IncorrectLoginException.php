<?php
/**
 * User: Andy
 * Date: 10/02/2014
 * Time: 16:54
 */

namespace AVCMS\Bundles\Users\Exception;

class IncorrectLoginException extends \Exception
{
    
} 