<?php
/**
 * User: Andy
 * Date: 23/03/2014
 * Time: 15:03
 */

namespace AVCMS\Bundles\Users\Exception;

class PermissionDeniedException extends \Exception
{
    
} 