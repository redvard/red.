<?php

namespace AVCMS\Bundles\Users\Form;

use AVCMS\Bundles\Admin\Form\AdminFiltersForm;

class UserGroupsAdminFiltersForm extends AdminFiltersForm
{
}