<?php
/**
 * User: Andy
 * Date: 12/01/15
 * Time: 17:44
 */

namespace AVCMS\Bundles\FacebookConnect\Security\Exception;

use Symfony\Component\Security\Core\Exception\AuthenticationException;

class FacebookAccountNotFoundException extends AuthenticationException
{
    
}
