<?php
/**
 * User: Andy
 * Date: 06/02/15
 * Time: 13:54
 */

namespace AVCMS\Bundles\Games\Form;

use AVCMS\Bundles\Categories\Form\CategoryAdminForm;

class GamesCategoryAdminForm extends CategoryAdminForm
{

}
