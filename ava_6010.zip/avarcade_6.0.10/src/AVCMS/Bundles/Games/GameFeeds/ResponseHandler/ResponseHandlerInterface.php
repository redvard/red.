<?php
/**
 * User: Andy
 * Date: 08/02/15
 * Time: 13:49
 */

namespace AVCMS\Bundles\Games\GameFeeds\ResponseHandler;

interface ResponseHandlerInterface
{
    public function getGames($response);
}
